function Set-ScheduleWallpaper {
    if((get-date).dayofweek -eq 'Sunday'){& powershell.exe Set-LDSWallpaper}
    if((get-date).dayofweek -eq 'Monday'){& powershell.exe Set-RandomWallpaper}
    if((get-date).dayofweek -eq 'Tuesday'){& powershell.exe Set-RandomWallpaper}
    if((get-date).dayofweek -eq 'Wednesday'){& powershell.exe Set-RandomWallpaper}
    if((get-date).dayofweek -eq 'Thursday'){& powershell.exe Set-RandomWallpaper}
    if((get-date).dayofweek -eq 'Friday'){& powershell.exe Set-RandomWallpaper}
    if((get-date).dayofweek -eq 'Saturday'){& powershell.exe Set-RandomWallpaper}
}